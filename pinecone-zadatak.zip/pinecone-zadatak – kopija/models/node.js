const mongoose = require("mongoose");

const NodeSchema = mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  title: { type: String, required: true },
  parent_id: {
    type: Number,
    ref: "Node",
    default: null,
  },
  ordering: { type: Number, required: true },
});

const Node = mongoose.model("Node", NodeSchema);

const initializeDatabase = async () => {
  const root = await Node.findOne({ id: 1 });
  if (!root) {
    await Node.create({
      id: 1,
      title: "Root",
      parent_id: null,
      ordering: 0,
    });
  }
};

initializeDatabase();

module.exports = Node;
